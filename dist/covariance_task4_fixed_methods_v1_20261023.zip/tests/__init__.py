"""Project verification tests."""
