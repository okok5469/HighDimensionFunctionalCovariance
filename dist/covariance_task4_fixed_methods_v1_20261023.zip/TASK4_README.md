﻿# Task 4：固定算法的有限模型参数搜索

本包使用独立 study `task4_fixed_methods_v1`、发布版本及输出目录；保留原 task3 源码、确认锁和结果。开发只做离线测试、小规模冒烟及打包，没有连接集群、取消旧作业或运行完整探索。

## 配置与环境

ZIP 为 `dist/covariance_task4_fixed_methods_v1_20261023.zip` 及相邻 `.sha256`；集中配置为根目录 `cluster_config_task4.example.json`；入口为 `dist/submit_task4.ps1`。可独立携带入口、配置、ZIP、校验四类文件。

目标环境沿用 `module load anaconda3; conda activate myenv`，Python 3.9.25、NumPy 2.0.2、SciPy 1.13.1；节点检查版本及 pandas/matplotlib/tqdm 可导入性。不要在集群安装本地 requirements。

复制配置为 `cluster_config_task4.json`，填写 SSH 的 host/port/user/authentication（agent 或 identity_file）和必要的 identity_file；填写六个资源预算：bootstrap_memory_mb/bootstrap_time_minutes、control_memory_mb/control_time_minutes、worker_memory_limit_mb/worker_time_limit_minutes。未知项目保留 null，不能猜测。SSH 私钥不上传，需提前核实主机指纹。

默认从仓库根目录执行，package_file 为 `dist/...zip`；若四类文件放同一文件夹，改成 ZIP 文件名。不要更改原环境。

## 本机操作

在 PowerShell 仓库根目录执行，复制后用编辑器填写集中配置：

```powershell
Copy-Item cluster_config_task4.example.json cluster_config_task4.json
powershell -NoProfile -File .\dist\submit_task4.ps1 -Config .\cluster_config_task4.json -DryRun
powershell -NoProfile -File .\dist\submit_task4.ps1 -Config .\cluster_config_task4.json
powershell -NoProfile -File .\dist\submit_task4.ps1 -Config .\cluster_config_task4.json -Action status
powershell -NoProfile -File .\dist\submit_task4.ps1 -Config .\cluster_config_task4.json -Action resume
powershell -NoProfile -File .\dist\submit_task4.ps1 -Config .\cluster_config_task4.json -Action download
```

DryRun 列缺项与流程，不联网、不上传。启动会上传至 `<remote_project_dir>/.task4_upload/<ZIP_SHA256>/`，逐文件校验后部署到 `<remote_project_dir>/releases/<ZIP_SHA256>/`；登录节点仅运行控制器，计算全部经 sbatch。返回 PID 只表示启动接受，结合返回的 controller_log 和 status 确认阶段。相同 run 用 resume，不能重复 start 或改源码与原配置再 resume；未确认 sbatch 回执会停止，禁止直接删除 intent 重提。

自动执行 smoke → init → B=500 同形状节点基准 → 600 份 pilot → 完整性收集 → 条件性150份 fallback（至多一次）→ 固定选择与不可变锁 → 至多2200份独立确认 → 汇总。无合格候选可正常结束，不自动扩展搜索。数组并发最多8，环境初始化阻塞锁、逐记录锁与控制器锁防止竞争重复写入。

资源按真实生产基准乘2倍时间/内存余量并受配置上限约束，超预算明确停止；估算不承诺排队或实际墙钟时间。查询采用用户级 squeue，不对过期ID调用 squeue --jobs；sacct 不用旧集群不支持的 --array，accounting 缺失不视为完成，失败日志保留 stderr。

## 收获结果

远端默认输出：

```text
/public/home/xjh/xmx/high_dimension_functional_data_covariance/results/task4_fixed_methods_v1/task4_fixed_methods_v1_20261023/
```

controller_state.json 的 stage=done 后核对 pilot_integrity.json，以及触发时的 fallback_integrity.json 和确认存在时的 confirm_integrity.json，均须 complete=true。search_decision.json.action=done_no_eligible_candidates 且没有确认锁是预定停止，不能解释为找到有利模型。

输出含阶段 plan、records 四方法配对原始记录、integrity/failures、summary/paired_comparisons/runtime_summary、candidate_selection.csv、fallback_trigger.json（触发时）、confirm_locked.json（入选时）、search_decision.json 及 TASK4_RESULTS_REPORT.md。下载保留整个 run 到配置 download_dir。探索入选和冒烟均不是正式优势证据。

## 切换前只读核实旧运行

开发没有查询远程当前旧任务。使用原 task3 配置的 status，结合集群 `squeue -u "$USER"`、原 run 的 controller_state.json/serial_recovery_state.json、提交历史、工作目录和日志核实归属；不要按报告历史ID或按用户批量取消。实际运行方需处理已核实仍在运行的旧后续流程，避免两套确认并行消耗预算；保留全部旧结果、源码和锁。

## 复核

模型与规则见 TASK4_DGP_AND_SEARCH_SPEC.md，真实验证及限制见 TASK4_IMPLEMENTATION_REPORT.md。ZIP 含实际源码、配置、测试、环境依赖说明、doc/task4_frozen_before.json，以及 manifest.json/SHA256SUMS；不可覆盖已生成包，变更应另建版本。
