import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

plt.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei', 'Arial Unicode MS']
plt.rcParams['axes.unicode_minus'] = False
plt.rcParams['font.size'] = 11

df1 = pd.read_csv('all_experiments_results.csv')   # 模型 M1
df2 = pd.read_csv('model2_results.csv')            # 模型 M2

# ====================================================================
# 图 4.1  两模型经验水平对比（实验 1）
# ====================================================================
exp1_m1 = df1[df1['experiment'] == 1].sort_values(['n', 'p'])
exp1_m2 = df2[df2['experiment'] == 1].sort_values(['n', 'p'])
labels = [f"n={int(r.n)}\np={int(r.p)}" for _, r in exp1_m1.iterrows()]

x = np.arange(len(labels))
width = 0.35
fig, ax = plt.subplots(figsize=(7.5, 4.5))
b1 = ax.bar(x - width/2, exp1_m1['reject_rate'].values, width,
            label='M1 (傅里叶基)', color='#3b7dd8', edgecolor='black')
b2 = ax.bar(x + width/2, exp1_m2['reject_rate'].values, width,
            label='M2 (布朗运动)', color='#e07b39', edgecolor='black')

ax.axhline(0.05, color='red', linestyle='--', linewidth=1.5,
           label=r'名义水平 $\alpha=0.05$')
mc_se = np.sqrt(0.05 * 0.95 / 100)
ax.fill_between([-0.5, len(labels) - 0.5],
                0.05 - 2 * mc_se, 0.05 + 2 * mc_se,
                color='red', alpha=0.1, label='±2 MC SE')

for bars in (b1, b2):
    for bar in bars:
        h = bar.get_height()
        ax.text(bar.get_x() + bar.get_width()/2, h + 0.002,
                f'{h:.2f}', ha='center', fontsize=9)

ax.set_xticks(x); ax.set_xticklabels(labels)
ax.set_ylabel('经验拒绝率')
ax.set_ylim(0, 0.10)
ax.set_xlim(-0.5, len(labels) - 0.5)
ax.set_title('图 4.1  两模型在 $H_0$ 下的经验水平对比')
ax.legend(loc='upper right', fontsize=9)
plt.tight_layout()
plt.savefig('fig41_size_comparison.pdf', dpi=300, bbox_inches='tight')
plt.show()

# ====================================================================
# 图 4.2  两模型经验功效对比（实验 2）
# ====================================================================
exp2_m1 = df1[df1['experiment'] == 2].sort_values(['s0', 'signal_strength'])
exp2_m2 = df2[df2['experiment'] == 2].sort_values(['s0', 'signal_strength'])

labels = [f"$s_0$={int(r.s0)}\n$\\delta$={r.signal_strength}"
          for _, r in exp2_m1.iterrows()]
x = np.arange(len(labels))
fig, ax = plt.subplots(figsize=(7.5, 4.5))
b1 = ax.bar(x - width/2, exp2_m1['power'].values, width,
            label='M1 (傅里叶基)', color='#3b7dd8', edgecolor='black')
b2 = ax.bar(x + width/2, exp2_m2['power'].values, width,
            label='M2 (布朗运动)', color='#e07b39', edgecolor='black')
ax.axhline(0.05, color='red', linestyle='--', linewidth=1, alpha=0.5,
           label=r'$\alpha=0.05$')
for bars in (b1, b2):
    for bar in bars:
        h = bar.get_height()
        ax.text(bar.get_x() + bar.get_width()/2, h + 0.02,
                f'{h:.2f}', ha='center', fontsize=9)
ax.set_xticks(x); ax.set_xticklabels(labels)
ax.set_ylabel('经验功效')
ax.set_ylim(0, 1.18)
ax.set_title('图 4.2  两模型在 $H_a$ 下的经验功效对比 ($n=200,\\ p=50$)')
ax.legend(loc='upper left', fontsize=9)
plt.tight_layout()
plt.savefig('fig42_power_comparison.pdf', dpi=300, bbox_inches='tight')
plt.show()

# ====================================================================
# 图 4.3  两模型高维行为（实验 3）
# ====================================================================
exp3_m1 = df1[df1['experiment'] == 3].sort_values('p_over_n')
exp3_m2 = df2[df2['experiment'] == 3].sort_values('p_over_n')

fig, axes = plt.subplots(1, 2, figsize=(11, 4.2))

# 左：功效 vs p/n
ax = axes[0]
ax.plot(exp3_m1['p_over_n'], exp3_m1['power'], 'o-',
        markersize=11, linewidth=2, label='M1', color='#3b7dd8')
ax.plot(exp3_m2['p_over_n'], exp3_m2['power'], 's-',
        markersize=11, linewidth=2, label='M2', color='#e07b39')
for _, r in exp3_m1.iterrows():
    ax.annotate(f'p={int(r.p)}', (r.p_over_n, r.power),
                xytext=(8, -14), textcoords='offset points', fontsize=9)
ax.set_xlabel(r'维度比 $p/n$')
ax.set_ylabel('经验功效')
ax.set_ylim(0, 1.15)
ax.grid(True, alpha=0.3)
ax.legend()
ax.set_title(r'(a) 经验功效随 $p/n$ 变化 ($n=200,\ \delta=0.6$)')

# 右：耗时 vs p
ax = axes[1]
ax.plot(exp3_m1['p'], exp3_m1['time'], 'o-',
        markersize=11, linewidth=2, label='M1', color='#3b7dd8')
ax.plot(exp3_m2['p'], exp3_m2['time'], 's-',
        markersize=11, linewidth=2, label='M2', color='#e07b39')
ax.set_xlabel(r'维度 $p$')
ax.set_ylabel('耗时 (秒)')
ax.grid(True, alpha=0.3)
ax.legend()
ax.set_title('(b) 单组合耗时随 $p$ 变化')

plt.tight_layout()
plt.savefig('fig43_highdim.pdf', dpi=300, bbox_inches='tight')
plt.show()