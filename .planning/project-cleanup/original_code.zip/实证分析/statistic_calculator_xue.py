﻿# statistic_calculator_xue.py
import numpy as np


def compute_Tn_xue(Y, s=None, eps=1e-10):
    """
    鍗曟牱鏈?Xue 鍨?studentized 鏋佸€肩粺璁￠噺锛堝崟鏍锋湰鍖栫畝鐗堬級
        T_n = log log(ps) - 4 log(ps) + max_{j1!=j2} n * sigma_hat^2 / m_hat

    鍙傛暟:
        Y: (n, p, M) 杈撳叆寮犻噺
        s: 鍩哄睍寮€鎴柇椤规暟锛團ourier 鍩哄嚱鏁颁釜鏁帮紝鍗?q_smooth锛夈€?
           榛樿涓?None 鏃朵娇鐢?M锛屼絾寤鸿鏄惧紡浼犲叆姝ｇ‘鐨?s 鍊笺€?
    杩斿洖:
        Tn (float)
    """
    n, p, M = Y.shape
    if s is None:
        s = M  # 鍚戝悗鍏煎锛岄粯璁ゅ€?
    Y_flat = Y.reshape(n, p * M)
    Yc = Y_flat - Y_flat.mean(0, keepdims=True)

    # 鍗忔柟宸紙鐢?1/n 涓?Xue 鐞嗚淇濇寔涓€鑷达級
    sigma_2d = (Yc.T @ Yc) / n                       # (pM, pM)

    # 4 闃剁煩浼拌:  m_ab = E[xi_a^2 xi_b^2] - sigma_ab^2
    Yc2 = Yc ** 2
    E_xi2 = (Yc2.T @ Yc2) / n                        # (pM, pM)
    m_hat = E_xi2 - sigma_2d ** 2
    m_hat = np.maximum(m_hat, eps)

    # Studentized statistic
    studentized = n * sigma_2d ** 2 / m_hat          # (pM, pM)

    # Reshape 鍒?(p, p, M, M) 骞跺彇 j1 != j2 鍧楃殑鏈€澶у€?
    s_4d = studentized.reshape(p, M, p, M).transpose(0, 2, 1, 3)  # (p, p, M, M)
    mask = ~np.eye(p, dtype=bool)
    max_val = s_4d[mask].max()

    Tn = max_val - 4.0 * np.log(p * s) + np.log(np.log(p * s))
    return Tn


def xue_critical_value(alpha):
    """Gumbel 娓愯繎涓寸晫鍊? tau_alpha = -log(8 pi) - 2 log log(1/(1-alpha))"""
    return -np.log(8 * np.pi) - 2 * np.log(np.log(1.0 / (1.0 - alpha)))


def xue_pvalue(Tn):
    """鍩轰簬 Gumbel CDF 鐨?p-value: P(T > Tn) = 1 - F(Tn)"""
    a = (8 * np.pi) ** -0.5
    z = a * np.exp(-Tn / 2)
    return -np.expm1(-z)


def gumbel_pdf(x):
    """对应的 PDF（绘图用）"""
    a = (8 * np.pi) ** -0.5
    return a * 0.5 * np.exp(-x / 2) * np.exp(-a * np.exp(-x / 2))
