import os

os.chdir(r'c:\XiangMingXu\会同杯\数据、代码包\实证分析')

from empirical_data_loader import prepare_empirical_data
from empirical_main import sanity_check

cache = 'cache/empirical_data.pkl'
if os.path.exists(cache):
    os.remove(cache)

try:
    data = prepare_empirical_data(n=200, p=50, M=48, q=5)
    print('Y_smooth', data['Y_smooth'].shape)
    print('symbols', len(data['symbols']))
    print('names', len(data['names']))
    print('mean_corr', sanity_check(data))
except Exception as e:
    import traceback
    traceback.print_exc()
